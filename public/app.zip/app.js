const wrapper = document.getElementById("tickerWrapper");
const postsList = document.getElementById("postsList");

async function fetchPosts() {
  try {
    const res = await fetch("/api/posts");
    const posts = await res.json();

    postsList.innerHTML = "";

    posts.forEach(p => {
      const li = document.createElement("li");

      const link = document.createElement("a");
      link.href = p.link;
      link.textContent = p.title;
      link.target = "_blank";

      const date = document.createElement("span");
      date.className = "post-date";
      date.textContent = new Date(p.date).toLocaleString();

      // QR kod
      const qr = document.createElement("img");
      qr.className = "qr";
      qr.src = `https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(p.link)}`;
      qr.alt = "QR";

      li.appendChild(link);
      li.appendChild(date);
      li.appendChild(qr);
      postsList.appendChild(li);
    });
  } catch (err) {
    console.error("Greška pri učitavanju:", err);
  }
}

function startAutoScroll() {
  let direction = 1; // 1 = dole, -1 = gore
  const step = 1;    // px po pomeraju
  const delay = 30;  // interval u ms (manje = brže)

  setInterval(() => {
    wrapper.scrollTop += direction * step;

    if (wrapper.scrollTop + wrapper.clientHeight >= wrapper.scrollHeight) {
      direction = -1; // promeni pravac na dnu
    }
    if (wrapper.scrollTop <= 0) {
      direction = 1;  // promeni pravac na vrhu
    }
  }, delay);
}

window.addEventListener("load", () => {
  fetchPosts().then(() => {
    startAutoScroll();
  });
});
